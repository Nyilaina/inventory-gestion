<?php
$sidonneesinvalides = false;
$sitoutok = false;
$liste_objet_faisable = ['modification', 'insertion', 'suppression'];
$i = 0;
if(isset($_POST['objet']) && isset($_POST['sujet']) && isset($_POST['id'])) {
    if(in_array($_POST['objet'], $liste_objet_faisable) && preg_match("#^[0-9]{1,}$#", $_POST['id']) && in_array($_POST['sujet'], $liste_table_bdd)) {
		if($_POST['objet'] == 'suppression') {
            $req = $bdd->prepare('DELETE FROM ' . $_POST['sujet'] . ' WHERE id = :id');
            $req->execute(array( 'id' => $_POST['id'] ));
            $req->closeCursor();
            $sitoutok = true;
        }
        else {
            // Pour modification et suppression
            if($_POST['objet'] == 'insertion') {
                $string_requete2 = 'SELECT MAX(id) AS maxid FROM ' . $_POST['sujet'];
                $req2 = $bdd->query($string_requete2);
                while($donnees_temp = $req2->fetch()) {
                    $_POST['id'] = $donnees_temp['maxid'];
                }
                $_POST['id']++;
                $req2->closeCursor();
            }
            $sujet;
            $liste_nom_champs_sujet = [];
            $liste_regex_champs_sujet = [];
            $liste_null_champs_sujet = [];
            $liste_valeur_champs_sujet = [];
            $nombre_champs = 0;
            if($_POST['sujet'] == 'article') {
                include_once('class/Article.class.php');
                $sujet = new Article($_POST['objet']);
            }
            else if($_POST['sujet'] == 'fournisseur') {
                include_once('class/Fournisseur.class.php');
                $sujet = new Fournisseur($_POST['objet']);
            }
            else if($_POST['sujet'] == 'groupement') {
                include_once('class/Groupement.class.php');
                $sujet = new Groupement($_POST['objet']);
            }
            else {
                $sidonneesinvalides = true;
            }
            $liste_nom_champs_sujet = $sujet->get_liste_nom_champs();
            $liste_regex_champs_sujet = $sujet->get_liste_regex_champs();
            $liste_null_champs_sujet = $sujet->get_liste_null_champs();
            $nombre_champs = $sujet->get_nombre_champs();
            for($i = 0; $i < $nombre_champs; $i++) {
                if(isset($_POST[$liste_nom_champs_sujet[$i]])) {
                    if(!preg_match($liste_regex_champs_sujet[$i], $_POST[$liste_nom_champs_sujet[$i]])) {
                        $_POST[$liste_nom_champs_sujet[$i]] = $liste_null_champs_sujet[$i];
                    }
                    $liste_valeur_champs_sujet[] = $_POST[$liste_nom_champs_sujet[$i]];
                }
                else {
                    $sidonneesinvalides = true;
                }
            }
            if(!$sidonneesinvalides) {
                $sujet->set_array_requete_bdd($liste_valeur_champs_sujet);
                $req = $bdd->prepare($sujet->get_string_requete());
                $req->execute($sujet->get_array_requete_bdd());
                $req->closeCursor();
                if($_POST['sujet'] == 'article'){
                    include_once('modifierliaison.php');
                }
                $sitoutok = true;
            }
        }
    }
    else {
        $sidonneesinvalides = true;
    }
}
else {
    $sidonneesinvalides = true;
}
/*echo '<pre>';
print_r($_POST);
echo '</pre>';//*/
if($sitoutok) {
    if(isset($_POST['redirection'])) {
        header('Location: index.php?page=' . $_POST['redirection']);
    }
    else {
        header('Location: index.php?page=' . $_POST['sujet']);
    }
}
else if($sidonneesinvalides) {
    header('Location: index.php?page=erreur&objet=donneesmanquant');
}
else {
    header('Location: index.php');
}//*/
?>