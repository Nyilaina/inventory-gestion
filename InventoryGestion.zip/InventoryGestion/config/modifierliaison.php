<?php
$idmax = 0;
$req = $bdd->prepare('DELETE FROM liaisonarticlegrpt WHERE idarticle = :idarticle');
$req->execute(array( 'idarticle' => $_POST['id'] ));
$req->closeCursor();

$req2 = $bdd->query('SELECT MAX(id) AS maxid FROM liaisonarticlegrpt');
while($donnees_temp = $req2->fetch()) {
    $idmax = $donnees_temp['maxid'];
}
$req2->closeCursor();
$idmax++;

if($_POST['objet'] == 'insertion' || $_POST['objet'] == 'modification') {
    foreach($_POST as $cle => $element) {
        if(preg_match("#^(inputgrpt)[0-9]{1,}$#", $cle)) {
            $string_requete = 'INSERT INTO liaisonarticlegrpt (id, idarticle, idgroupement) VALUES (:id, ';
            $string_requete .= ':idarticle, :idgroupement)';
            $req = $bdd->prepare($string_requete);
            $req->execute(array(
                'id' => $idmax,
                'idarticle' => $_POST['id'],
                'idgroupement' => substr($cle, 9, strlen($cle) - 9)
            ));
            $req->closeCursor();
            $idmax++;
        }
    }
}
?>