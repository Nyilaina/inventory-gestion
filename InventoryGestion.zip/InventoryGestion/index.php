<?php
    include_once('modele/encodage.php');
    include_once('modele/bddconnect.php');
    include_once('modele/bddtableliste.php');
    $list_config_pages = ['modifierarticle', 'modifierfournisseur'];
    $list_pages = ['article', 'fournisseur', 'parametre', 'about_us'];
    $list_nom_pages = ['Tableau de bord', 'Fournisseur', 'Param&egrave;tre', '&Agrave; propos de nous'];
    $class_theme_couleur = 'normal';
    if(isset($_GET['page'])) {
        if(in_array($_GET['page'], $list_config_pages)) {
            include('pages/' . $_GET['page'] . '.php');
        }
        elseif(in_array($_GET['page'], $list_pages)) {
            include('pages/' . $_GET['page'] . '.php');
        }
        else {
            include('pages/main.php');
        }
    }
    else if(isset($_POST['objet'])) {
        if($_POST['objet'] == 'optimiser' || $_POST['objet'] == 'formater') {
            $class_theme_couleur = 'sanglant';
            include('pages/operationbdd.php');
        }
        else {
            include('pages/main.php');
        }
    }
    else {
        include('pages/main.php');
    }
?>