<?php
    include('head.php');
    include('header.php');
    include('navigation.php');
?>
<section class="section_premier">
<h1>&Agrave; propos de nous</h1>
<p>
    Besoin d'assistance technique ?
</p>
<p>
    Appelez-nous au (+261) 330000000 ou envoyez-nous un mail au 
    <a href="mailto:blabla@truc.com">blabla@truc.com</a></p>
</section>
<?php
    include('bottom.php');
?>