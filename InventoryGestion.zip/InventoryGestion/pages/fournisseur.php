<?php
    include('head.php');
    include('header.php');
    include('navigation.php');
?>
<?php
    $string_requete = 'SELECT * FROM fournisseur ORDER BY id';

    $fournisseur_id = [];
    $fournisseur_nom = [];
    $fournisseur_adresse = [];
    $fournisseur_reference = [];
    $fournisseur_description = [];
    $fournisseur_compteur = 0;

    $req = $bdd->query($string_requete);
	while($donnees_temp = $req->fetch())
	{
        $fournisseur_id[$fournisseur_compteur] = $donnees_temp['id'];
        $fournisseur_nom[$fournisseur_compteur] = $donnees_temp['nom'];
        $fournisseur_adresse[$fournisseur_compteur] = $donnees_temp['adresse'];
        $fournisseur_reference[$fournisseur_compteur] = $donnees_temp['reference'];
        $fournisseur_description[$fournisseur_compteur] = $donnees_temp['description'];
        $fournisseur_compteur++;
	}
	$req->closeCursor();
?>
<section class="section_premier">
<h1>Liste des fournisseurs</h1>
    <table id="table_fournisseur" class="table_liste" cellpadding="0" cellspacing="0">
        <tr>
            <th>Nom</th>
            <th>Adresse</th>
            <th>R&eacute;f&eacute;rence</th>
            <th>Note</th>
        </tr>
        <?php
        $i = 0;
        for($i = 0; $i < $fournisseur_compteur; $i++) {
            echo '
            <tr class="tr_cliquable" id="tr' . $i . '">
                <td class="displaynone + donnees_fournisseur_id">' . $fournisseur_id[$i] . '</td>
                <td class="donnees_fournisseur_nom">' . $fournisseur_nom[$i] . '</td>
                <td class="donnees_fournisseur_adresse">' . $fournisseur_adresse[$i] . '</td>
                <td class="donnees_fournisseur_reference">' . $fournisseur_reference[$i] . '</td>
                <td class="donnees_fournisseur_description">' . $fournisseur_description[$i] . '</td>
            </tr>';
        }
        ?>
    </table>
    <p class="aligncenter">
        <a href="?page=modifierfournisseur&objet=nouveau" class="bouton_1">Ajouter nouveau</a>
    </p>
</section>
<section id="section_overlay">
    <div class="overlay_remplisseur">&nbsp;</div>
    <div class="overlay_conteneur_remplisseur">
    <div class="overlay_remplisseur">&nbsp;</div>
        <div class="overlay_conteneur" id="overlay_ppale">
            <p class="overlay_titre + flexnone + nonselectionnable">Informations sur un enregistrement en particulier</p>
            <table>
            <tr class="displaynone">
                <td></td>
                <td><input type="text" name="" id="input_table_th_dynamique_id"></td>
            </tr>
            <tr>
                <td>Nom : </td>
                <td><input type="text" name="nom" id="input_table_th_dynamique_nom" class="width200 + inputdisabledblanc" disabled="disabled"></td>
            </tr>
            <tr>
                <td>Adresse : </td>
                <td><input type="text" name="adresse" id="input_table_th_dynamique_adresse" class="width200 + inputdisabledblanc" disabled="disabled"></td>
            </tr>
            <tr>
                <td>R&eacute;f&eacute;rence : </td>
                <td><input type="text" name="reference" id="input_table_th_dynamique_reference" class="width200 + inputdisabledblanc" disabled="disabled"></td>
            </tr>
            <tr>
                <td>Note : </td>
                <td><input type="text" name="description" id="input_table_th_dynamique_description" class="width200 + inputdisabledblanc" disabled="disabled"></td>
            </tr>
            </table>
            <p class="aligncenter + flexnone + nonselectionnable">
                <span class="bouton_2 + marginx10" id="bouton_supprimer_fournisseur">Supprimer</span>
                <span class="bouton_1" id="bouton_modifier_fournisseur">Modifier</span>
            </p>
        </div>
        <div class="overlay_conteneur + overlay_suppression + nonselectionnable" id="overlay_suppression">
            <p class="overlay_titre + flexnone">Confirmation de suppression</p>
            <p class="margin10 + marginbottom0 + flex11">Voulez-vous vraiment supprimer cet entr&eacute; ?<br>
            La suppression d'un enregistrement est irr&eacute;versible.</p>
            <p class="aligncenter + margin10 + padding0 + flexnone">
                <span class="bouton_2 + marginx10" id="bouton_confirmer_supprimer_fournisseur">Oui</span>
                <span class="bouton_1" id="bouton_annuler_supprimer_fournisseur">Annuler</span>
            </p>
        </div>
        <div class="overlay_remplisseur">&nbsp;</div>
    </div>
    <div class="overlay_remplisseur">&nbsp;</div>
    <form action="config.php" method="post" class="displaynone" id="formsuppression">
        <input type="text" name="id" id="inputid">
        <input type="text" name="objet" id="inputobjet" value="suppression">
        <input type="text" name="sujet" id="inputsujet" value="fournisseur">
        <input type="text" name="link" id="inputlink" value="modifierligne">
    </form>
</section>
<script src="js/fournisseur.js"></script>
<?php
    include('bottom.php');
?>