<?php
    include('head.php');
    include('header.php');
    include('navigation.php');
?>
<section class="section_premier">
<h1><?php
    $groupement_id = [];
    $groupement_nom = [];
    $groupement_description = [];
    $groupement_nombre_article = [];

    $string_requete = 'SELECT * FROM groupement ORDER BY nombre_article';
    $req = $bdd->query($string_requete);
    while($donnees_temp = $req->fetch()) {
        $groupement_id[] = $donnees_temp['id'];
        $groupement_nom[] = $donnees_temp['nom'];
        $groupement_description[] = $donnees_temp['description'];
        $groupement_nombre_article[] = $donnees_temp['nombre_article'];
    }
    $req->closeCursor();
?>Param&egrave;tre</h1>
    <h3 class="aligncenter">Base de donn&eacute;es</h3>
    <p class="aligncenter">Op&eacute;rations sur la base de donn&eacute;es</p>
    <p class="aligncenter"><input type="button" value="Optimiser" id="bouton_optimiser_bdd" class="bouton_1">
        <input type="button" value="Formater" id="bouton_formater_bdd" class="bouton_2"></p>
    <p><br></p>
    <h3 class="aligncenter">Liste des groupements</h3>
    <table id="table_groupement" cellpadding="0" cellspacing="0" class="table_liste">
        <tr>
            <th class="displaynone">id</th>
            <th>D&eacute;signation</th>
            <th>Description</th>
            <th>Nombre d'article</th>
        </tr>
        <?php
            for($i = 0; $i < count($groupement_id); $i++) {
                echo '
                <tr class="tr_cliquable" id="tr' . $i . '">
                <td class="displaynone + donnees_groupement_id">' . $groupement_id[$i] .'</td>
                <td class="donnees_groupement_nom">' . $groupement_nom[$i] .'</td>
                <td class="donnees_groupement_description">' . $groupement_description[$i] .'</td>
                <td class="donnees_groupement_nombre_article">' . $groupement_nombre_article[$i] .'</td>
            </tr>';
            }
        ?>
    </table>
    <p class="aligncenter">
        <span class="bouton_1" id="bouton_ajouter_nouveau_groupement">Ajouter nouveau</span>
    </p>
</section>
<section id="section_overlay">
    <div class="overlay_remplisseur">&nbsp;</div>
    <div class="overlay_conteneur_remplisseur">
    <div class="overlay_remplisseur">&nbsp;</div>
        <div class="overlay_conteneur" id="overlay_ppale">
            <p class="overlay_titre + flexnone + nonselectionnable">Modification d'un groupement</p>
            <form action="config.php" method="post" id="formmodification">
                <table>
                <tr class="displaynone">
                    <td><input type="text" name="id" id="input_dynamique_id" value="">
                        <input type="text" name="objet" id="inputobjet" value="">
                        <input type="text" name="sujet" id="inputsujet" value="groupement">
                        <input type="text" name="link" id="inputlink" value="modifierligne">
                        <input type="text" name="redirection" id="inputredirection" value="parametre"></td>
                </tr>
                <tr>
                    <td>D&eacute;signation: </td>
                    <td class="paddingleft10"><input type="text" name="nom" id="input_dynamique_nom" value="" class="width200"></td>
                </tr>
                <tr>
                    <td>Description: </td>
                    <td class="paddingleft10">
                    <textarea name="description" id="textarea_dynamique_description" cols="10" rows="2" class="width200 + displayinlineblock"></textarea></td>
                </tr>
                <tr>
                    <td>Nombre d'article: </td>
                    <td class="paddingleft10"><input type="text" name="nombre_article" id="input_dynamique_nombre_article" value="" class="width200"></td>
                </tr>
                </table>
            </form>
            
            <p class="aligncenter + margin10 + flexnone + nonselectionnable">
                <span class="bouton_2 + marginx10" id="bouton_supprimer_groupement">Supprimer</span>
                <span class="bouton_1" id="bouton_enregistrer_groupement">Enregistrer</span>
            </p>
        </div>
        <div class="overlay_conteneur + overlay_suppression + nonselectionnable" id="overlay_suppression">
            <p class="overlay_titre + flexnone">Confirmation de suppression</p>
            <p class="margin10 + marginbottom0 + flex11">Voulez-vous vraiment supprimer cet entr&eacute; ?<br>
            La suppression d'un enregistrement est irr&eacute;versible.</p>
            <p class="aligncenter + margin10 + padding0 + flexnone">
                <span class="bouton_2 + marginx10" id="bouton_confirmer_supprimer_groupement">Oui</span>
                <span class="bouton_1" id="bouton_annuler_supprimer_groupement">Annuler</span>
            </p>
        </div>
        <div class="overlay_conteneur + overlay_suppression + nonselectionnable" id="overlay_bdd">
            <p class="overlay_titre + flexnone">Confirmation</p>
            <p class="overlay_message + margin10 + marginbottom0 + flex11">Vraiment ?</p>
            <p class="aligncenter + margin10 + padding0 + flexnone">
                <span class="bouton_2 + marginx10" id="bouton_confirmer_bdd">Lancer (!)</span>
                <span class="bouton_1" id="bouton_annuler_bdd">Annuler</span>
            </p>
        </div>
        <div class="overlay_remplisseur">&nbsp;</div>
    </div>
    <div class="overlay_remplisseur">&nbsp;</div>
    <form action="config.php" method="post" class="displaynone" id="formsuppression">
        <input type="text" name="id" id="inputsuppressionid">
        <input type="text" name="objet" id="inputsuppressionobjet" value="suppression">
        <input type="text" name="sujet" id="inputsuppressionsujet" value="groupement">
        <input type="text" name="link" id="inputsuppressionlink" value="modifierligne">
        <input type="text" name="redirection" id="inputredirection" value="parametre">
    </form>
    <form action="index.php" method="post" class="displaynone" id="formbdd">
        <input type="text" name="objet" id="inputobjetbdd" value="">
    </form>
</section>
<script src="js/parametre.js"></script>
<?php
    include('bottom.php');
?>