<?php
    include('head.php');
    include('header.php');
    include('navigation.php');
?>
<section class="aligncenter + section_premier">
<h1><?php
    $simodification = false;

    $article_id = '';
    $article_nom = '';
    $article_description = '';
    $article_pu = '';
    $article_idfournisseurselected = '';
    $article_nbtotale = '';
    $article_nbpargrpt = '';

    $fournisseur_id = [];
    $fournisseur_nom = [];

    $groupement_id = [];
    $groupement_nom = [];

    $groupement_id_selectionnee = [];

    $string_requete = 'SELECT id, nom FROM fournisseur ORDER BY id';
    $req = $bdd->query($string_requete);
    while($donnees_temp = $req->fetch()) {
        $fournisseur_id[] = $donnees_temp['id'];
        $fournisseur_nom[] = $donnees_temp['nom'];
    }
    $req->closeCursor();
    
    $string_requete = 'SELECT id, nom FROM groupement ORDER BY nombre_article DESC';
    $req = $bdd->query($string_requete);
    while($donnees_temp = $req->fetch()) {
        $groupement_id[] = $donnees_temp['id'];
        $groupement_nom[] = $donnees_temp['nom'];
    }
    $req->closeCursor();

    if(isset($_GET['objet'])) {
        if($_GET['objet'] == 'modification' && isset($_GET['id'])) {
            $simodification = true;
            echo 'Modification des données d\'un article';
    
            $string_requete = 'SELECT article.id AS id, article.nom AS nom, article.description AS descript, ';
            $string_requete .= 'article.prix_unitaire AS pu, fournisseur.id AS idfournisseurselected, ';
            $string_requete .= 'article.nombre AS nbtotale ';
            $string_requete .= 'FROM article ';
            $string_requete .= 'LEFT JOIN fournisseur ';
            $string_requete .= 'ON fournisseur.id = article.idfournisseur ';
            $string_requete .= 'WHERE article.id = :articleid';
            
	        $req = $bdd->prepare($string_requete); 
	        $req->execute(array(    'articleid' => $_GET['id']));
            while($donnees_temp = $req->fetch()) {
                $article_id = $donnees_temp['id'];
                $article_nom = $donnees_temp['nom'];
                $article_description = $donnees_temp['descript'];
                $article_pu = $donnees_temp['pu'];
                $article_idfournisseurselected = $donnees_temp['idfournisseurselected'];
                $article_nbtotale = $donnees_temp['nbtotale'];
            }
            $req->closeCursor();
    
            $string_requete = 'SELECT groupement.id AS idselectionnee FROM groupement INNER JOIN liaisonarticlegrpt ';
            $string_requete .= 'ON groupement.id = liaisonarticlegrpt.idgroupement WHERE liaisonarticlegrpt.idarticle ';
            $string_requete .= '= :articleid';
            $req = $bdd->prepare($string_requete); 
            $req->execute(array(    'articleid' => $_GET['id']));
            while($donnees_temp = $req->fetch()) {
                $groupement_id_selectionnee[] = $donnees_temp['idselectionnee'];
            }
            $req->closeCursor();
        }
        else {
            echo 'Ajout d\'un nouveau article';
            $article_id = 0;
        }
    }
    else {
        echo 'Ajout d\'un nouveau article';
        $article_id = 0;
    }
?></h1>
<form action="config.php" method="post">
<table class="alignleft + marginauto">
    <tr class="displaynone">
        <td>id</td>
        <td><input type="text" name="id" id="inputid" value="<?php echo $article_id; ?>">
        <input type="text" name="objet" id="inputobjet" value="<?php if($simodification) echo 'modification'; else echo'insertion'; ?>">
        <input type="text" name="sujet" id="inputsujet" value="article">
        <input type="text" name="link" id="inputlink" value="modifierligne"></td>
    </tr>
    <tr>
        <td>Nom : </td>
        <td><input type="text" name="nom" id="inputnom" value="<?php echo $article_nom; ?>" class="width200"></td>
    </tr>
    <tr>
        <td>Description : </td>
        <td><textarea name="description" id="textareadescription" cols="10" rows="2" class="width200 + displayinlineblock"><?php echo $article_description; ?></textarea></td>
    </tr>
    <tr>
        <td>Prix unitaire : </td>
        <td><input type="text" name="prix_unitaire" id="inputpu" value="<?php echo $article_pu; ?>" class="width200"></td>
    </tr>
    <tr>
        <td>Fournisseur :</td>
        <td><select name="idfournisseur" id="selectfournisseur" class="width200 + displayinlineblock">
            <?php
            for($i = 0; $i < count($fournisseur_id); $i++) {
                if($fournisseur_id[$i] == $article_idfournisseurselected) {
                    echo '
                    <option value="' . $fournisseur_id[$i] . '" selected>' . $fournisseur_nom[$i] . '</option>';
                }
                else {
                    echo '
                    <option value="' . $fournisseur_id[$i] . '">' . $fournisseur_nom[$i] . '</option>';
                }
            }
            ?>
        </select></td>
    </tr>
    <tr>
        <td>Nombre totale : </td>
        <td><input type="text" name="nombre" id="inputnbtotale" value="<?php echo $article_nbtotale; ?>" class="width200"></td>
    </tr>
    <tr>
        <td>Groupement : </td>
        <td><?php
            for($i = 0; $i < count($groupement_id); $i++) {
                if(in_array($groupement_id[$i], $groupement_id_selectionnee)){
                    echo '
                    <input type="checkbox" name="inputgrpt' . $groupement_id[$i] .
                    '" id="' . $groupement_id[$i] .'" checked><label for="' . $groupement_id[$i] .'">' .
                    $groupement_nom[$i] . '</label><br />';
                }
                else {
                    echo '
                    <input type="checkbox" name="inputgrpt' . $groupement_id[$i] .
                    '" id="' . $groupement_id[$i] .'"><label for="' . $groupement_id[$i] .'">' .
                    $groupement_nom[$i] . '</label><br />';
                }
            }
            ?></td>
    </tr>
</table>
    <p>
        <?php if($simodification) echo '<input type="button" class="bouton_2" value="Supprimer" id="bouton_supprimer_article">'; ?>
        <input type="submit" class="bouton_1" value="Enregistrer" id="bouton_enregistrer_article">
        <input type="button" class="bouton_1" value="Annuler" id="bouton_annuler_article">
    </p>
    </form>
</section><?php
if($simodification) {
    echo '
    <section id="section_overlay">
        <div class="overlay_remplisseur">&nbsp;</div>
        <div class="overlay_conteneur_remplisseur">
        <div class="overlay_remplisseur">&nbsp;</div>
        <div class="overlay_conteneur + overlay_suppression" id="overlay_suppression">
            <p class="overlay_titre + flexnone">Confirmation de suppression</p>
            <p class="margin10 + marginbottom0 + flex11">Voulez-vous vraiment supprimer cet entr&eacute; ?<br>
            La suppression d\'un enregistrement est irr&eacute;versible.</p>
            <p class="aligncenter + margin10 + padding0 + flexnone">
                    <span class="bouton_2 + marginx10" id="bouton_confirmer_supprimer_article">Oui</span>
                    <span class="bouton_1" id="bouton_annuler_supprimer_article">Annuler</span>
                </p>
            </div>
            <div class="overlay_remplisseur">&nbsp;</div>
        </div>
        <div class="overlay_remplisseur">&nbsp;</div>
        <form action="config.php" method="post" class="displaynone" id="formsuppression">
            <input type="text" name="id" id="inputidsuppression" value="' . $article_id . '">
            <input type="text" name="objet" id="inputobjet" value="suppression">
            <input type="text" name="sujet" id="inputsujet" value="article">
            <input type="text" name="link" id="inputlink" value="modifierligne">
        </form>
    </section>';
}
?>
<script src="js/modifierarticle.js"></script>
<?php
    include('bottom.php');
?>