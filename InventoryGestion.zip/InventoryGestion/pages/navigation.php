<nav class="nav_<?php echo $class_theme_couleur; ?>">
    <ul>
        <?php
        for($i = 0; $i < count($list_nom_pages); $i++) {
            echo '
            <li><a href="?page=' . $list_pages[$i] . '">' . $list_nom_pages[$i] . '</a></li>
            ';
        }
        ?>
    </ul>
</nav>