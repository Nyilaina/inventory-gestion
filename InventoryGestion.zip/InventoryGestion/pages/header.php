<header class="header_<?php echo $class_theme_couleur; ?>">
    <h3><a href="index.php">Inventory Gestion</a></h3>
    <h6><a href="index.php">&copy; 2021</a></h6>
</header>