<?php
    include('head.php');
    include('header.php');
    include('navigation.php');
?>
<section class="section_premier">
<h1>Page d'accueil centralisé</h1>
<p>Les CRUD sur les articles, les fournisseurs et les groupements sont terminés.</p>
<p>Il reste l'encodage, les fonctions de recherche, de tri et de limitation des lignes, et la page "&Agrave; propos de nous" &agrave; faire.</p>
<p><span id="spanavider">Vous allez &ecirc;tre redirig&eacute; dans </span><span id="spansecondes">5 secondes.</span>
<span id="spanannulerredirection" class="bouton_annuler_redir">Annuler X</span></p>
</section>
<script src="js/accueil.js"></script>
<?php
    include('bottom.php');
?>