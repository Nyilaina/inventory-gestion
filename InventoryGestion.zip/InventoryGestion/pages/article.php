<?php
    include('head.php');
    include('header.php');
    include('navigation.php');
?>
<?php
    $article_id = [];
    $article_nom = [];
    $article_description = [];
    $article_pu = [];
    $article_fournisseur = [];
    $article_nbtotale = [];
    $article_nbpargrpt = [];
    $article_nbpargrpt_simple_temp = [];
    $article_nomgrpt_simple_temp = [];
    $article_nbpargrpt_double = [];
    $article_nomgrpt_double = [];
    $article_groupement_id_selectionnee = [];
    $article_compteur = 0;
    $article_groupement_id_selectionnee_temp = '';

    $string_requete = 'SELECT article.id AS id, article.nom AS nom, article.description AS descript, article.prix_unitaire AS pu, ';
    $string_requete .= 'fournisseur.nom AS fournisseur, article.nombre AS nbtotale ';
    $string_requete .= 'FROM article ';
    $string_requete .= 'LEFT JOIN fournisseur ';
    $string_requete .= 'ON fournisseur.id = article.idfournisseur ORDER BY article.id';

    $req = $bdd->query($string_requete);
	while($donnees_temp = $req->fetch()) {
        $article_id[] = $donnees_temp['id'];
        $article_nom[] = $donnees_temp['nom'];
        $article_description[] = $donnees_temp['descript'];
        $article_pu[] = $donnees_temp['pu'];
        $article_fournisseur[] = $donnees_temp['fournisseur'];
        $article_nbtotale[] = $donnees_temp['nbtotale'];
        $article_compteur++;
	}
    $req->closeCursor();

    for($temp_i = 0; $temp_i < count($article_id); $temp_i++) {
        $string_requete = 'SELECT groupement.id AS idselectionnee, ';
        $string_requete .= 'groupement.nombre_article AS nbartpargrpt, groupement.nom AS nomgrpt ';
        $string_requete .= 'FROM groupement  ';
        $string_requete .= 'INNER JOIN liaisonarticlegrpt ';
        $string_requete .= 'ON groupement.id = liaisonarticlegrpt.idgroupement ';
        $string_requete .= 'WHERE liaisonarticlegrpt.idarticle ';
        $string_requete .= '= :articleid';
        $article_nbpargrpt_simple_temp = [];
        $article_nomgrpt_simple_temp = [];
        $article_groupement_id_selectionnee_temp = '';
        $req = $bdd->prepare($string_requete); 
        $req->execute(array(    'articleid' => $article_id[$temp_i]));
        while($donnees_temp = $req->fetch()) {
            $article_groupement_id_selectionnee_temp .= $donnees_temp['idselectionnee'] . ' ';
            $article_nbpargrpt_simple_temp[] = $donnees_temp['nbartpargrpt'];
            $article_nomgrpt_simple_temp[] = $donnees_temp['nomgrpt'];
        }
        $article_groupement_id_selectionnee_temp = trim($article_groupement_id_selectionnee_temp);
        $article_groupement_id_selectionnee[] = $article_groupement_id_selectionnee_temp;
        $article_nbpargrpt_double[] = $article_nbpargrpt_simple_temp;
        $article_nomgrpt_double[] = $article_nomgrpt_simple_temp;
        $req->closeCursor();
    }
    
    $string_requete = 'SELECT id, nom FROM groupement ORDER BY nombre_article DESC';
    $req = $bdd->query($string_requete);
    while($donnees_temp = $req->fetch()) {
        $groupement_id[] = $donnees_temp['id'];
        $groupement_nom[] = $donnees_temp['nom'];
    }
    $req->closeCursor();
?>
<section class="section_premier">
<h1>Tableau de bord (liste des articles)</h1>
    <table id="table_article" class="table_liste" cellpadding="0" cellspacing="0">
        <tr>
            <th class="displaynone">id</th>
            <th class="displaynone">idgrptselectionnee</th>
            <th>Nom</th>
            <th>Description</th>
            <th>PU</th>
            <th>Fournisseur</th>
            <th>Nb. totale</th>
            <th>Nb. par grpt</th>
        </tr>
        <?php
        $i = 0;
        $article_nb_reste = 0;
        $article_dividende = 0;
        $article_nb_string_resultat = '';
        $article_nomgrpt_double_compteur = 0;
        for($i = 0; $i < $article_compteur; $i++) {
            echo '
            <tr class="tr_cliquable" id="tr' . $i . '">
                <td class="displaynone + donnees_article_id">' . $article_id[$i] . '</td>
                <td class="displaynone + donnees_article_idgrptselectionnee">' . $article_groupement_id_selectionnee[$i] . '</td>
                <td class="donnees_article_nom">' . $article_nom[$i] . '</td>
                <td class="donnees_article_description">' . $article_description[$i] . '</td>
                <td class="donnees_article_pu">' . $article_pu[$i] . '</td>
                <td class="donnees_article_fournisseur">' . $article_fournisseur[$i] . '</td>
                <td class="donnees_article_nbtotale">' . $article_nbtotale[$i] . '</td>
                <td class="donnees_article_nbpargrpt">';
                $article_nb_reste = $article_nbtotale[$i];
                $article_nb_string_resultat = '';
                $article_nomgrpt_double_compteur = 0;
                foreach($article_nbpargrpt_double[$i] as $temp_article_nbpargrpt_double_ligne) {
                    $article_dividende = (int) ($article_nb_reste / $temp_article_nbpargrpt_double_ligne);
                    $article_nb_reste = $article_nb_reste % $temp_article_nbpargrpt_double_ligne;
                    $article_nb_string_resultat .= $article_dividende . ' ' . $article_nomgrpt_double[$i][$article_nomgrpt_double_compteur] . ', ';
                    $article_nomgrpt_double_compteur++;
                }
                $article_nb_string_resultat .= ' ' . $article_nb_reste . ' pcs';
                echo $article_nb_string_resultat;
            echo '</td>
            </tr>';
        }
        ?>
    </table>
    <p class="aligncenter">
        <a href="?page=modifierarticle&objet=nouveau" class="bouton_1">Ajouter nouveau</a>
    </p>
</section>
<section id="section_overlay">
    <div class="overlay_remplisseur">&nbsp;</div>
    <div class="overlay_conteneur_remplisseur">
    <div class="overlay_remplisseur">&nbsp;</div>
        <div class="overlay_conteneur" id="overlay_ppale">
            <p class="overlay_titre + flexnone + nonselectionnable">Informations sur un enregistrement en particulier</p>
            <form action="control.php" method="post" id="formmodification">
            <table>
            <tr class="displaynone">
                <td><input type="text" name="id" id="input_table_th_dynamique_id"></td>
            </tr>
            <tr>
                <td>Nom: </td>
                <td><input type="text" name="nom" id="input_table_th_dynamique_nom" class="width200 + inputdisabledblanc" disabled="disabled"></td>
            </tr>
            <tr>
                <td>Description: </td>
                <td><input type="text" name="description" id="input_table_th_dynamique_description" class="width200 + inputdisabledblanc" disabled="disabled"></td>
            </tr>
            <tr>
                <td>Prix unitaire: </td>
                <td><input type="text" name="prix_unitaire" id="input_table_th_dynamique_pu" class="width200 + inputdisabledblanc" disabled="disabled"></td>
            </tr>
            <tr>
                <td>Fournisseur: </td>
                <td><input type="text" name="idfournisseur" id="input_table_th_dynamique_idfournisseur" class="width200 + inputdisabledblanc" disabled="disabled"></td>
            </tr>
            <tr>
                <td>Nombre totale: </td>
                <td><input type="text" name="nombre" id="input_table_th_dynamique_nombre" class="width200 + inputdisabledblanc" disabled="disabled"></td>
            </tr>
            <tr>
                <td>Groupement: </td>
                <td><?php
            for($i = 0; $i < count($groupement_id); $i++) {
                echo '
                <input type="checkbox" class="inputgrpt + inputdisabledblanc" name="inputgrpt' . $groupement_id[$i] .
                '" id="inputgrpt' . $groupement_id[$i] .'" disabled="true"><label for="inputgrpt' . $groupement_id[$i] .'">' .
                $groupement_nom[$i] . '</label><br />';
            }
            ?></td>
            </tr>
            </table>
            </form>
            <p class="aligncenter + margin10 + flexnone + nonselectionnable">
                <span class="bouton_2 + marginx10" id="bouton_supprimer_article">Supprimer</span>
                <span class="bouton_1" id="bouton_modifier_article">Modifier</span>
            </p>
        </div>
        <div class="overlay_conteneur + overlay_suppression + nonselectionnable" id="overlay_suppression">
            <p class="overlay_titre + flexnone">Confirmation de suppression</p>
            <p class="margin10 + marginbottom0 + flex11">Voulez-vous vraiment supprimer cet entr&eacute; ?<br>
            La suppression d'un enregistrement est irr&eacute;versible.</p>
            <p class="aligncenter + margin10 + padding0 + flexnone">
                <span class="bouton_2 + marginx10" id="bouton_confirmer_supprimer_article">Oui</span>
                <span class="bouton_1" id="bouton_annuler_supprimer_article">Annuler</span>
            </p>
        </div>
        <div class="overlay_remplisseur">&nbsp;</div>
    </div>
    <div class="overlay_remplisseur">&nbsp;</div>
    <form action="config.php" method="post" class="displaynone" id="formsuppression">
        <input type="text" name="id" id="inputid">
        <input type="text" name="objet" id="inputobjet" value="suppression">
        <input type="text" name="sujet" id="inputsujet" value="article">
        <input type="text" name="link" id="inputlink" value="modifierligne">
    </form>
</section>
<script src="js/article.js"></script>
<?php
    include('bottom.php');
?>