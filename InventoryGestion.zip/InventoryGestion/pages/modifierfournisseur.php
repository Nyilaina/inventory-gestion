<?php
    include('head.php');
    include('header.php');
    include('navigation.php');
?>
<section class="aligncenter + section_premier">
<h1><?php
    $simodification = false;

    $fournisseur_id = '';
    $fournisseur_nom = '';
    $fournisseur_adresse = '';
    $fournisseur_reference = '';
    $fournisseur_description = '';

    if(isset($_GET['objet'])) {
        if($_GET['objet'] == 'modification') {
            $simodification = true;

            echo 'Modification des données d\'un fournisseur';
            
            $string_requete = 'SELECT * FROM fournisseur WHERE id = :id';
            
	        $req = $bdd->prepare($string_requete); 
	        $req->execute(array(    'id' => $_GET['id']));
            while($donnees_temp = $req->fetch()) {
                $fournisseur_id = $donnees_temp['id'];
                $fournisseur_nom = $donnees_temp['nom'];
                $fournisseur_adresse = $donnees_temp['adresse'];
                $fournisseur_reference = $donnees_temp['reference'];
                $fournisseur_description = $donnees_temp['description'];
            }
            $req->closeCursor();
        }
        else {
            echo 'Ajout d\'un nouveau fournisseur';
            $fournisseur_id = 0;
        }
    }
    else {
        echo 'Ajout d\'un nouveau fournisseur';
    }
?></h1>
<form action="config.php" method="post">
<table class="marginauto + alignleft">
    <tr class="displaynone">
        <td>id</td>
        <td><input type="text" name="id" id="inputid" value="<?php echo $fournisseur_id; ?>">
        <input type="text" name="objet" id="inputobjet" value="<?php if($simodification) echo 'modification'; else echo'insertion'; ?>">
        <input type="text" name="sujet" id="inputsujet" value="fournisseur">
        <input type="text" name="link" id="inputlink" value="modifierligne"></td>
    </tr>
    <tr>
        <td>Nom : </td>
        <td><input type="text" name="nom" id="inputnom" value="<?php echo $fournisseur_nom; ?>" class="width200"></td>
    </tr>
    <tr>
        <td>Adresse : </td>
        <td><input type="text" name="adresse" id="inputadresse" value="<?php echo $fournisseur_adresse; ?>" class="width200"></td>
    </tr>
    <tr>
        <td>R&eacute;&eacute;rence : </td>
        <td><input type="text" name="reference" id="inputreference" value="<?php echo $fournisseur_reference; ?>" class="width200"></td>
    </tr>
    <tr>
        <td>Note : </td>
        <td><textarea name="description" id="textareadescription" cols="10" rows="2" class="width200 + displayinlineblock"><?php echo $fournisseur_description; ?></textarea></td>
    </tr>
</table>
    <p>
        <?php if($simodification) echo '<input type="button" class="bouton_2" value="Supprimer" id="bouton_supprimer_fournisseur">'; ?>
        <input type="submit" class="bouton_1" value="Enregistrer" id="bouton_enregistrer_fournisseur">
        <input type="button" class="bouton_1" value="Annuler" id="bouton_annuler_fournisseur">
    </p>
    </form>
</section><?php
if($simodification) {
    echo '
    <section id="section_overlay">
        <div class="overlay_remplisseur">&nbsp;</div>
        <div class="overlay_conteneur_remplisseur">
        <div class="overlay_remplisseur">&nbsp;</div>
        <div class="overlay_conteneur + overlay_suppression" id="overlay_suppression">
            <p class="overlay_titre + flexnone">Confirmation de suppression</p>
            <p class="margin10 + marginbottom0 + flex11">Voulez-vous vraiment supprimer cet entr&eacute; ?<br>
            La suppression d\'un enregistrement est irr&eacute;versible.</p>
            <p class="aligncenter + margin10 + padding0 + flexnone">
                    <span class="bouton_2 + marginx10" id="bouton_confirmer_supprimer_fournisseur">Oui</span>
                    <span class="bouton_1" id="bouton_annuler_supprimer_fournisseur">Annuler</span>
                </p>
            </div>
            <div class="overlay_remplisseur">&nbsp;</div>
        </div>
        <div class="overlay_remplisseur">&nbsp;</div>
        <form action="config.php" method="post" class="displaynone" id="formsuppression">
            <input type="text" name="id" id="inputidsuppression" value="' . $fournisseur_id . '">
            <input type="text" name="objet" id="inputobjet" value="suppression">
            <input type="text" name="sujet" id="inputsujet" value="fournisseur">
            <input type="text" name="link" id="inputlink" value="modifierligne">
        </form>
    </section>';
}
?>
<script src="js/modifierfournisseur.js"></script>
<?php
    include('bottom.php');
?>