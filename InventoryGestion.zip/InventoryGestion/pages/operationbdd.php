<?php
    include('head.php');
    include('header.php');
    include('navigation.php');
?>
<section class="aligncenter + section_premier">
    <div class="section_div_dark">
    <h1>Op&eacute;ration non recommandable sur la base de donn&eacute;es</h1>
    <p class="alignleft">Vous &ecirc;tes s&ucirc;r de vouloir <?php echo $_POST['objet']; ?> la base de donn&eacute;es ?</p>
    <p class="alignleft"><?php
        if($_POST['objet'] == 'optimiser') {
            echo 'ATTENTION!!! Faites une sauvegarde avant d\'effectuer cet action, car l\'interruption de 
            l\'optimisation peut d&eacute;truire l\'int&eacute;gralit&eacute; de la base de donn&eacute;es.';
        }
        else if($_POST['objet'] == 'formater') {
            echo 'ATTENTION!!! Cet action est irr&eacute;versible et vous allez perdre l\'int&eacute;gralit&eacute;
            des donn&eacute;es actuellement enregistr&eacute;es dans la base de donn&eacute;es.';
        }
    ?></p>
    <form action="" method="post">
        <p>Op&eacute;ration int&eacute;rrompue automatiquement dans </span><span id="spansecondes">45 secondes.</span></p>
        <p>Mot de passe : <input type="password" name="" id="" class="width200"></p>
        <p><input type="button" value="<?php 
                $temp_string = strtoupper(substr($_POST['objet'], 0, 1)) . substr($_POST['objet'], 1, strlen($_POST['objet']));
                echo $temp_string; ?> (!)" class="bouton_2" id="bouton_confirmer_operation_bdd">
            <input type="button" value="Annuler" class="bouton_1" id="bouton_annuler_operation_bdd">
        </p>
    </form>
    </div>
</section>
<script src="js/operationbdd.js"></script>
<?php
    include('bottom.php');
?>