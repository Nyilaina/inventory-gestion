<?php
class Article {
    protected $liste_nom_champs;
    protected $liste_regex_champs;
    protected $liste_null_champs;
    protected $string_requete;
    protected $array_requete_bdd;
    protected $nombre_champs;

    public function __construct($temp_objet_manipulation) {
        $this->liste_nom_champs = [
            'id',
            'nom',
            'description',
            'prix_unitaire',
            'idfournisseur',
            'nombre'
        ];
        $this->nombre_champs = count($this->liste_nom_champs);
        $this->liste_null_champs = ['0', '', '', '', '0', '0'];
        $this->liste_regex_champs = [
            '#^[0-9]{1,}$#',
            '##',
            '##',
            '##',
            '#^[0-9]{1,}$#',
            '#^[0-9]{1,}$#'
        ];
        if($temp_objet_manipulation == 'modification') {
            $this->string_requete = 'UPDATE article SET nom = :nom, description = :description, ';
            $this->string_requete .= 'prix_unitaire = :prix_unitaire, idfournisseur = :idfournisseur, ';
            $this->string_requete .= 'nombre = :nombre WHERE id = :id';
        }
        else if($temp_objet_manipulation == 'insertion') {
            $this->string_requete = 'INSERT INTO article (id, nom, description, prix_unitaire, idfournisseur, ';
            $this->string_requete .= 'nombre) VALUES (:id, :nom, :description, :prix_unitaire, :idfournisseur, ';
            $this->string_requete .= ':nombre)';
        }
        $this->array_requete_bdd = array(
            'id' => '',
            'nom' => '',
            'description' => '',
            'prix_unitaire' => '',
            'idfournisseur' => '',
            'nombre' => ''
        );
    }

    public function get_liste_nom_champs() {
        return $this->liste_nom_champs;
    }
    public function get_liste_regex_champs() {
        return $this->liste_regex_champs;
    }
    public function get_liste_null_champs() {
        return $this->liste_null_champs;
    }
    public function get_nombre_champs() {
        return $this->nombre_champs;
    }
    public function set_array_requete_bdd($temp_liste) {
        $temp_i = 0;
        for($temp_i = 0; $temp_i < $this->nombre_champs; $temp_i++) {
            $this->array_requete_bdd[$this->liste_nom_champs[$temp_i]] = $temp_liste[$temp_i];
        }
    }
    public function get_array_requete_bdd() {
        return $this->array_requete_bdd;
    }
    public function get_string_requete() {
        return $this->string_requete;
    }
}
?>