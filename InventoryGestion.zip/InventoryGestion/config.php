<?php
    include_once('modele/encodage.php');
    include_once('modele/bddconnect.php');
    include_once('modele/bddtableliste.php');
    $list_config_links = ['modifierligne'];
    if(isset($_POST['link'])) {
        if(in_array($_POST['link'], $list_config_links)) {
            include('config/' . $_POST['link'] . '.php');
        }
        else {
            header('Location: index.php');
        }
    }
    else {
        header('Location: index.php');
    }
?>