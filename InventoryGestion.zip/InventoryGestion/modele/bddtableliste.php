<?php
    $liste_table_bdd = ['article', 'fournisseur', 'liaisonarticlegrpt', 'groupement'];
?>