var timersecondes = 45;
var sidejapasse = false;
var spansecondes = document.querySelector('#spansecondes');

setInterval(function(){
    if(!sidejapasse) {
        spansecondes.innerHTML = timersecondes + ' secondes.';
    }
    if(timersecondes > 0) {
        timersecondes--;
    }
    else {
        timersecondes = 15;
        location = 'index.php';
    }
}, 1000);

document.querySelector('#bouton_annuler_operation_bdd').addEventListener('click', function() {
    location = 'index.php';
}, false);

document.querySelector('#bouton_confirmer_operation_bdd').addEventListener('click', function() {
    alert('Non !');
}, false);