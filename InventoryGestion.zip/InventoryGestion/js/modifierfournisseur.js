document.querySelector('#bouton_annuler_fournisseur').addEventListener('click', function(){
    location = '?page=fournisseur';
}, false);

if(document.querySelector('#bouton_supprimer_fournisseur')) {
    var bouton_supprimer_fournisseur = document.querySelector('#bouton_supprimer_fournisseur');
    var bouton_annuler_supprimer_fournisseur = document.querySelector('#bouton_annuler_supprimer_fournisseur');
    var bouton_confirmer_supprimer_fournisseur = document.querySelector('#bouton_confirmer_supprimer_fournisseur');
    
    bouton_supprimer_fournisseur.addEventListener('click', function() {
        document.querySelector('#section_overlay').style.display = 'flex';
    }, false);
    bouton_annuler_supprimer_fournisseur.addEventListener('click', function() {
        document.querySelector('#section_overlay').style.display = 'none';
    }, false);
    bouton_confirmer_supprimer_fournisseur.addEventListener('click', function() {
        document.querySelector('#section_overlay').style.display = 'none';
        document.querySelector('#section_overlay #formsuppression').submit();
    }, false);
    
    var remplisseurs_overlay =  document.querySelectorAll('#section_overlay .overlay_remplisseur');
    for(i= 0;i < remplisseurs_overlay.length; i++) {
        remplisseurs_overlay[i].addEventListener('click', function() {
            document.querySelector('#section_overlay').style.display = 'none';
        }, false)
    }
}