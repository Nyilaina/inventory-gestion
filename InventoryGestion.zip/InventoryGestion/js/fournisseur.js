var tr_cliquables = document.querySelectorAll('#table_fournisseur .tr_cliquable');
var liste_donnees_fournisseurs_id = document.querySelectorAll('.donnees_fournisseur_id');
var liste_donnees_fournisseurs_nom = document.querySelectorAll('.donnees_fournisseur_nom');
var liste_donnees_fournisseurs_adresse = document.querySelectorAll('.donnees_fournisseur_adresse');
var liste_donnees_fournisseurs_reference = document.querySelectorAll('.donnees_fournisseur_reference');
var liste_donnees_fournisseurs_description = document.querySelectorAll('.donnees_fournisseur_description');
var i = 0;
var n_tr_cliquable = 0;
var bouton_modifier_fournisseur = document.querySelector('#bouton_modifier_fournisseur');
var bouton_supprimer_fournisseur = document.querySelector('#bouton_supprimer_fournisseur');
var bouton_annuler_supprimer_fournisseur = document.querySelector('#bouton_annuler_supprimer_fournisseur');
var bouton_confirmer_supprimer_fournisseur = document.querySelector('#bouton_confirmer_supprimer_fournisseur');

bouton_modifier_fournisseur.addEventListener('click', function() {
    location = '?page=modifierfournisseur&objet=modification&id=' + document.querySelector('#input_table_th_dynamique_id').value;
}, false);
bouton_supprimer_fournisseur.addEventListener('click', function() {
    document.querySelector('#section_overlay #overlay_ppale').style.display = 'none';
    document.querySelector('#section_overlay #overlay_suppression').style.display = 'flex';
}, false);
bouton_annuler_supprimer_fournisseur.addEventListener('click', function() {
    document.querySelector('#section_overlay #overlay_ppale').style.display = 'flex';
    document.querySelector('#section_overlay #overlay_suppression').style.display = 'none';
}, false);
bouton_confirmer_supprimer_fournisseur.addEventListener('click', function() {
    document.querySelector('#section_overlay').style.display = 'none';
    document.querySelector('#section_overlay #formsuppression').submit();
}, false);

for(i = 0; i < tr_cliquables.length; i++) {
    tr_cliquables[i].addEventListener('click', function() {
        n_tr_cliquable = this.getAttribute('id').substring(2, this.getAttribute('id').length);
        document.querySelector('.overlay_titre').innerHTML = 'Informations sur un enregistrement en particulier';
        document.querySelector('#input_table_th_dynamique_id').value = liste_donnees_fournisseurs_id[n_tr_cliquable].innerHTML;
        document.querySelector('#input_table_th_dynamique_nom').value = liste_donnees_fournisseurs_nom[n_tr_cliquable].innerHTML;
        document.querySelector('#input_table_th_dynamique_adresse').value = liste_donnees_fournisseurs_adresse[n_tr_cliquable].innerHTML;
        document.querySelector('#input_table_th_dynamique_reference').value = liste_donnees_fournisseurs_reference[n_tr_cliquable].innerHTML;
        document.querySelector('#input_table_th_dynamique_description').value = liste_donnees_fournisseurs_description[n_tr_cliquable].innerHTML;
        document.querySelector('#section_overlay #overlay_ppale').style.display = 'flex';
        document.querySelector('#section_overlay #overlay_suppression').style.display = 'none';
        document.querySelector('#section_overlay #formsuppression #inputid').value = liste_donnees_fournisseurs_id[n_tr_cliquable].innerHTML;
        document.querySelector('#section_overlay').style.display = 'flex';
    }, false);
}

var remplisseurs_overlay =  document.querySelectorAll('#section_overlay .overlay_remplisseur');
for(i= 0;i < remplisseurs_overlay.length; i++) {
    remplisseurs_overlay[i].addEventListener('click', function() {
        document.querySelector('#section_overlay').style.display = 'none';
    }, false)
}
