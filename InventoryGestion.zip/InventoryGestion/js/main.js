/*var i = 0;
if(document.querySelector('nav')) {
    var nav_links = document.querySelectorAll('nav ul li');
    for(i = 0; i < nav_links.length; i++) {
        nav_links[i].addEventListener('click', function() {
            location = '?page=' + this.getAttribute('class');
        }, false);
    }
}//*/