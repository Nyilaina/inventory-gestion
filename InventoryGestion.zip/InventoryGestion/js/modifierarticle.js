document.querySelector('#bouton_annuler_article').addEventListener('click', function(){
    location = '?page=article';
}, false);

if(document.querySelector('#bouton_supprimer_article')) {
    var bouton_supprimer_article = document.querySelector('#bouton_supprimer_article');
    var bouton_annuler_supprimer_article = document.querySelector('#bouton_annuler_supprimer_article');
    var bouton_confirmer_supprimer_article = document.querySelector('#bouton_confirmer_supprimer_article');
    
    bouton_supprimer_article.addEventListener('click', function() {
        document.querySelector('#section_overlay').style.display = 'flex';
    }, false);
    bouton_annuler_supprimer_article.addEventListener('click', function() {
        document.querySelector('#section_overlay').style.display = 'none';
    }, false);
    bouton_confirmer_supprimer_article.addEventListener('click', function() {
        document.querySelector('#section_overlay').style.display = 'none';
        document.querySelector('#section_overlay #formsuppression').submit();
    }, false);
    
    var remplisseurs_overlay =  document.querySelectorAll('#section_overlay .overlay_remplisseur');
    for(i= 0;i < remplisseurs_overlay.length; i++) {
        remplisseurs_overlay[i].addEventListener('click', function() {
            document.querySelector('#section_overlay').style.display = 'none';
        }, false)
    }
}