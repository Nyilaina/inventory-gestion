var timersecondes = 5;
var spanavider = document.querySelector('#spanavider');
var spansecondes = document.querySelector('#spansecondes');
var spanannulerredirection = document.querySelector('#spanannulerredirection');

var timeinterval = setInterval(function(){
    spansecondes.innerHTML = timersecondes + ' secondes.';
    if(timersecondes > 0) {
        timersecondes--;
    }
    else {
        clearInterval(timeinterval);
        location = '?page=article';
    }
}, 1000);

spanannulerredirection.addEventListener('click', function(){
    clearInterval(timeinterval);
    spanavider.innerHTML = '';
    spansecondes.innerHTML = 'Redirection annul&eacute;'
    spanannulerredirection.style.display = 'none';
}, false);