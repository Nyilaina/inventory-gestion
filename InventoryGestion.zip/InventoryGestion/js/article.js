var tr_cliquables = document.querySelectorAll('#table_article .tr_cliquable');
var liste_donnees_articles_id = document.querySelectorAll('.donnees_article_id');
var liste_donnees_vrac_article_idgrptselectionnee = document.querySelectorAll('.donnees_article_idgrptselectionnee');
var liste_donnees_article_idgrptselectionnee = [];
var liste_double_donnees_article_idgrptselectionnee = [];
var liste_donnees_articles_nom = document.querySelectorAll('.donnees_article_nom');
var liste_donnees_articles_description = document.querySelectorAll('.donnees_article_description');
var liste_donnees_articles_pu = document.querySelectorAll('.donnees_article_pu');
var liste_donnees_articles_fournisseur = document.querySelectorAll('.donnees_article_fournisseur');
var liste_donnees_articles_nbtotale = document.querySelectorAll('.donnees_article_nbtotale');
var liste_donnees_articles_nbpargrpt = document.querySelectorAll('.donnees_article_nbpargrpt');
var input_checkboxgrpt = document.querySelectorAll('.inputgrpt');
var i = 0;
var ii = 0;
var n_tr_cliquable = 0;
var bouton_modifier_article = document.querySelector('#bouton_modifier_article');
var bouton_supprimer_article = document.querySelector('#bouton_supprimer_article');
var bouton_annuler_supprimer_article = document.querySelector('#bouton_annuler_supprimer_article');
var bouton_confirmer_supprimer_article = document.querySelector('#bouton_confirmer_supprimer_article');
var formmodification = document.querySelector('#formmodification');

formmodification.reset();
bouton_modifier_article.addEventListener('click', function() {
    document.querySelector('#section_overlay').style.display = 'none';
    location = '?page=modifierarticle&objet=modification&id=' + document.querySelector('#input_table_th_dynamique_id').value;
}, false);
bouton_supprimer_article.addEventListener('click', function() {
    document.querySelector('#section_overlay #overlay_ppale').style.display = 'none';
    document.querySelector('#section_overlay #overlay_suppression').style.display = 'flex';
}, false);
bouton_annuler_supprimer_article.addEventListener('click', function() {
    document.querySelector('#section_overlay #overlay_ppale').style.display = 'flex';
    document.querySelector('#section_overlay #overlay_suppression').style.display = 'none';
}, false);
bouton_confirmer_supprimer_article.addEventListener('click', function() {
    document.querySelector('#section_overlay').style.display = 'none';
    document.querySelector('#section_overlay #formsuppression').submit();
}, false);

for(i = 0; i < tr_cliquables.length; i++) {
    liste_donnees_article_idgrptselectionnee.push(liste_donnees_vrac_article_idgrptselectionnee[i].innerHTML);
    liste_double_donnees_article_idgrptselectionnee.push(liste_donnees_vrac_article_idgrptselectionnee[i].innerHTML.split(' '));
    tr_cliquables[i].addEventListener('click', function() {
        n_tr_cliquable = this.getAttribute('id').substring(2, this.getAttribute('id').length);
        document.querySelector('.overlay_titre').innerHTML = 'Informations sur un enregistrement en particulier';
        document.querySelector('#input_table_th_dynamique_id').value = liste_donnees_articles_id[n_tr_cliquable].innerHTML;
        document.querySelector('#input_table_th_dynamique_nom').value = liste_donnees_articles_nom[n_tr_cliquable].innerHTML;
        document.querySelector('#input_table_th_dynamique_description').value = liste_donnees_articles_description[n_tr_cliquable].innerHTML;
        document.querySelector('#input_table_th_dynamique_pu').value = liste_donnees_articles_pu[n_tr_cliquable].innerHTML;
        document.querySelector('#input_table_th_dynamique_idfournisseur').value = liste_donnees_articles_fournisseur[n_tr_cliquable].innerHTML;
        document.querySelector('#input_table_th_dynamique_nombre').value = liste_donnees_articles_nbtotale[n_tr_cliquable].innerHTML;
        //document.querySelector('#input_table_th_dynamique_nbpargrpt').value = liste_donnees_articles_nbpargrpt[n_tr_cliquable].innerHTML;
        document.querySelector('#section_overlay #overlay_ppale').style.display = 'flex';
        document.querySelector('#section_overlay #overlay_suppression').style.display = 'none';
        document.querySelector('#section_overlay #formsuppression #inputid').value = liste_donnees_articles_id[n_tr_cliquable].innerHTML;
        for (ii = 0; ii < input_checkboxgrpt.length; ii++) {
            input_checkboxgrpt[ii].checked = false;
        }
        if(liste_double_donnees_article_idgrptselectionnee[n_tr_cliquable] != ''){
            for(ii = 0; ii < liste_double_donnees_article_idgrptselectionnee[n_tr_cliquable].length; ii++) {
                document.querySelector('#inputgrpt' + liste_double_donnees_article_idgrptselectionnee[n_tr_cliquable][ii]).checked = true;
            }
        }
        document.querySelector('#section_overlay').style.display = 'flex';
    }, false);
}

var remplisseurs_overlay =  document.querySelectorAll('#section_overlay .overlay_remplisseur');
for(i= 0;i < remplisseurs_overlay.length; i++) {
    remplisseurs_overlay[i].addEventListener('click', function() {
        document.querySelector('#section_overlay').style.display = 'none';
    }, false)
}
