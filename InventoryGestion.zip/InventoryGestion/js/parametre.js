var tr_cliquables = document.querySelectorAll('#table_groupement .tr_cliquable');
var liste_donnees_groupements_id = document.querySelectorAll('.donnees_groupement_id');
var liste_donnees_groupements_nom = document.querySelectorAll('.donnees_groupement_nom');
var liste_donnees_groupements_description = document.querySelectorAll('.donnees_groupement_description');
var liste_donnees_groupements_nombre_article = document.querySelectorAll('.donnees_groupement_nombre_article');
var i = 0;
var n_tr_cliquable = 0;
var bouton_optimiser_bdd = document.querySelector('#bouton_optimiser_bdd');
var bouton_formater_bdd = document.querySelector('#bouton_formater_bdd');
var bouton_confirmer_bdd = document.querySelector('#bouton_confirmer_bdd');
var bouton_annuler_bdd = document.querySelector('#bouton_annuler_bdd');
var bouton_ajouter_nouveau_groupement = document.querySelector('#bouton_ajouter_nouveau_groupement');
var bouton_enregistrer_groupement = document.querySelector('#bouton_enregistrer_groupement');
var bouton_supprimer_groupement = document.querySelector('#bouton_supprimer_groupement');
var bouton_annuler_supprimer_groupement = document.querySelector('#bouton_annuler_supprimer_groupement');
var bouton_confirmer_supprimer_groupement = document.querySelector('#bouton_confirmer_supprimer_groupement');

bouton_optimiser_bdd.addEventListener('click', function() {
    document.querySelector('#section_overlay #overlay_ppale').style.display = 'none';
    document.querySelector('#section_overlay #overlay_suppression').style.display = 'none';
    document.querySelector('#section_overlay #overlay_bdd').style.display = 'flex';
    document.querySelector('#section_overlay #overlay_bdd .overlay_titre').innerHTML = 'Confirmation d\'optimisation';
    document.querySelector('#section_overlay #overlay_bdd .overlay_message').innerHTML = 'Voulez-vous vraiment optimiser la base de donn&eacute;es ?<br>';
    document.querySelector('#section_overlay #overlay_bdd .overlay_message').innerHTML += 'ATTENTION!!! Faites une sauvegarde avant d\'effectuer cet ';
    document.querySelector('#section_overlay #overlay_bdd .overlay_message').innerHTML += 'action, car l\'interruption de l\'optimisation peut ';
    document.querySelector('#section_overlay #overlay_bdd .overlay_message').innerHTML += 'd&eacute;truire l\'int&eacute;gralit&eacute; de la base de donn&eacute;es.';
    document.querySelector('#section_overlay #formbdd #inputobjetbdd').value = 'optimiser';
    bouton_confirmer_bdd.innerHTML = 'Optimiser (!)';
    document.querySelector('#section_overlay').style.display = 'flex';
}, false);
bouton_formater_bdd.addEventListener('click', function() {
    document.querySelector('#section_overlay #overlay_ppale').style.display = 'none';
    document.querySelector('#section_overlay #overlay_suppression').style.display = 'none';
    document.querySelector('#section_overlay #overlay_bdd').style.display = 'flex';
    document.querySelector('#section_overlay #overlay_bdd .overlay_titre').innerHTML = 'Confirmation de formatage';
    document.querySelector('#section_overlay #overlay_bdd .overlay_message').innerHTML = 'Voulez-vous vraiment formater la base de donn&eacute;es ?<br>';
    document.querySelector('#section_overlay #overlay_bdd .overlay_message').innerHTML += 'ATTENTION!!! Cet action est irr&eacute;versible et vous allez ';
    document.querySelector('#section_overlay #overlay_bdd .overlay_message').innerHTML += 'perdre l\'int&eacute;gralit&eacute; des donn&eacute;es ';
    document.querySelector('#section_overlay #overlay_bdd .overlay_message').innerHTML += 'actuellement enregistr&eacute;es dans la base de donn&eacute;es.';
    document.querySelector('#section_overlay #formbdd #inputobjetbdd').value = 'formater';
    bouton_confirmer_bdd.innerHTML = 'Formater (!)';
    document.querySelector('#section_overlay').style.display = 'flex';
}, false);
bouton_annuler_bdd.addEventListener('click', function() {
    document.querySelector('#section_overlay').style.display = 'none';
}, false);
bouton_confirmer_bdd.addEventListener('click', function() {
    document.querySelector('#section_overlay').style.display = 'none';
    document.querySelector('#section_overlay #formbdd').submit();
}, false);
bouton_ajouter_nouveau_groupement.addEventListener('click', function() {
    document.querySelector('.overlay_titre').innerHTML = 'Ajout d\'un nouveau groupement';
    document.querySelector('#inputobjet').value = 'insertion';
    document.querySelector('#input_dynamique_id').value = '0';
    document.querySelector('#input_dynamique_nom').value = '';
    document.querySelector('#textarea_dynamique_description').value = '';
    document.querySelector('#input_dynamique_nombre_article').value = '';
    document.querySelector('#section_overlay #overlay_ppale').style.display = 'flex';
    document.querySelector('#section_overlay #overlay_suppression').style.display = 'none';
    document.querySelector('#section_overlay #overlay_bdd').style.display = 'none';
    document.querySelector('#section_overlay #formsuppression #inputsuppressionid').value = '0';
    document.querySelector('#bouton_supprimer_groupement').style.display = 'none';
    document.querySelector('#section_overlay').style.display = 'flex';
}, false);
bouton_enregistrer_groupement.addEventListener('click', function() {
    document.querySelector('#section_overlay').style.display = 'none';
    document.querySelector('#section_overlay #formmodification').submit();
}, false);
bouton_supprimer_groupement.addEventListener('click', function() {
    document.querySelector('#section_overlay #overlay_ppale').style.display = 'none';
    document.querySelector('#section_overlay #overlay_suppression').style.display = 'flex';
}, false);
bouton_annuler_supprimer_groupement.addEventListener('click', function() {
    document.querySelector('#section_overlay #overlay_ppale').style.display = 'flex';
    document.querySelector('#section_overlay #overlay_suppression').style.display = 'none';
}, false);
bouton_confirmer_supprimer_groupement.addEventListener('click', function() {
    document.querySelector('#section_overlay').style.display = 'none';
    document.querySelector('#section_overlay #formsuppression').submit();
}, false);

for(i = 0; i < tr_cliquables.length; i++) {
    tr_cliquables[i].addEventListener('click', function() {
        n_tr_cliquable = this.getAttribute('id').substring(2, this.getAttribute('id').length);
        document.querySelector('.overlay_titre').innerHTML = 'Modification d\'un groupement';
        document.querySelector('#inputobjet').value = 'modification';
        document.querySelector('#input_dynamique_id').value = liste_donnees_groupements_id[n_tr_cliquable].innerHTML;
        document.querySelector('#input_dynamique_nom').value = liste_donnees_groupements_nom[n_tr_cliquable].innerHTML;
        document.querySelector('#textarea_dynamique_description').value = liste_donnees_groupements_description[n_tr_cliquable].innerHTML;
        document.querySelector('#input_dynamique_nombre_article').value = liste_donnees_groupements_nombre_article[n_tr_cliquable].innerHTML;
        document.querySelector('#section_overlay #overlay_ppale').style.display = 'flex';
        document.querySelector('#section_overlay #overlay_suppression').style.display = 'none';
        document.querySelector('#section_overlay #overlay_bdd').style.display = 'none';
        document.querySelector('#section_overlay #formsuppression #inputsuppressionid').value = liste_donnees_groupements_id[n_tr_cliquable].innerHTML;
        document.querySelector('#bouton_supprimer_groupement').style.display = 'inline-block';
        document.querySelector('#section_overlay').style.display = 'flex';
    }, false);
}

var remplisseurs_overlay =  document.querySelectorAll('#section_overlay .overlay_remplisseur');
for(i= 0;i < remplisseurs_overlay.length; i++) {
    remplisseurs_overlay[i].addEventListener('click', function() {
        document.querySelector('#section_overlay').style.display = 'none';
    }, false)
}
